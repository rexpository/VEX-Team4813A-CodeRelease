#include "api2.h"

void autonomous( void ) {

    /* initialize capabilities from buttons */
    bool allianceBlue = buttons[0].state;
    bool startTileFar = buttons[1].state;
    bool LowPercent = buttons[2].state;
    bool Nopenope = buttons[3].state;

 
    /* lower flag bumping code - only if near flag start tile */
    if(!startTileFar){            // Starting tile nearest to the flags/net
        if(!allianceBlue){        //not blue
         
        // STEP 1
        //backwards get ball
        //come back
        //turn right
        intake(68);
        drivebackwardDistance(60, 36.0);
        task::sleep(150);
        driveDistance(50, 35.63);
        task::sleep(250); 
        driveTurnRightDegrees(30, 92.09);
        task::sleep(150); 
        intake(68);
        
        // STEP 2
        //forward to middle
        //shoot flags
        //turn right
        //forward get cap
        //lif tup
        driveDistance(45, 9.36);
        task::sleep(150); 
        catapultauto();
        task::sleep(700); 
        driveTurnRightDegrees(30, 51);
        task::sleep(150);
        driveDistance(30, 10.83);
        task::sleep(150);
        Lift.rotateFor(0.6, rotationUnits::rev, 97, vex::velocityUnits::pct, false);  
        task::sleep(500);
        intake(68);
        task::sleep(25);
        
        //STEP 3
        //backwards a bit
        //turn left
        //backwards to post
        //turn rightface post
        //highpost
        //forward a bit
        drivebackwardDistance(30, 8.95);
        task::sleep(150);
        driveTurnLeftDegrees(30, 51);
        task::sleep(150);
        drivebackwardDistance(60, 20.94);
        task::sleep(150);
        highpostauto();    
        driveTurnRightDegrees(30, 92.09);
        task::sleep(150);
        highpostauto1();   
        task::sleep(300);
        highpostauto2();
        driveDistance(45, 6.30);

        // STEP 4
        // high post down
        // turn left face flags
        // forward to flags
        // shoot two flags
        Lift.rotateFor(-2.95, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
        LiftExtension.rotateFor(3.6, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
        intake(68);
        driveTurnLeftDegrees(30, 57); 
        task::sleep(25);
        driveDistance(100, 36.75);
        task::sleep(150);
        catapultauto();
        task::sleep(700);       

        }

        else if(allianceBlue){   //blue
// STEP 1
        //backwards get ball
        //come back
        //turn left
        intake(68);
        drivebackwardDistance(60, 36.0);
        task::sleep(150);
        driveDistance(50, 35.63);
        task::sleep(250); 
        driveTurnLeftDegrees(30, 92.09);
        task::sleep(150); 
        intake(68);
        
        // STEP 2
        //forward to middle
        //shoot flags
        //turn left
        //forward get cap
        //lif tup
        driveDistance(45, 9.36);
        task::sleep(150); 
        catapultauto();
        task::sleep(350); 
        driveTurnLeftDegrees(30, 51);
        task::sleep(150);
        driveDistance(30, 10.83);
        task::sleep(150);
        Lift.rotateFor(0.6, rotationUnits::rev, 97, vex::velocityUnits::pct, false);  
        task::sleep(500);
        intake(68);
        task::sleep(25);
        
        //STEP 3
        //backwards a it
        //turn right
        //backwards to post
        //turn left face post
        //highpost
        //forward a bit
        drivebackwardDistance(30, 8.95);
        task::sleep(150);
        driveTurnRightDegrees(30, 51);
        task::sleep(150);
        drivebackwardDistance(60, 20.94);
        task::sleep(150);
        highpostauto();    
        driveTurnLeftDegrees(30, 92.09);
        task::sleep(150);
        highpostauto1();   
        task::sleep(300);
        highpostauto2();
        driveDistance(45, 6.30);

        // STEP 4
        // high post down
        // turn right face flags
        // forward to flags
        // shoot two flags
        Lift.rotateFor(-2.95, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
        LiftExtension.rotateFor(3.6, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
        intake(68);
        driveTurnRightDegrees(30, 57); 
        task::sleep(25);
        driveDistance(100, 36.75);
        task::sleep(150);
        catapultauto();
        task::sleep(700);
        } 

    }  

    else if (startTileFar){ // far from flag/net starting tile
        if(!allianceBlue){        //not blue
    //get ball from under cap
    //turn left
    //get cap
    //lift up
    //turn right
    //lowpost
    //forward
    //turn left
    //lowpost
    //turn right
    //climb
        catapultauto1();    
        drivebackwardDistance(50, 40);
        intake(68);        
        driveTurnLeftDegrees(30, 90.5);
        task::sleep(150);  
        driveDistance(30, 15.8);
        task::sleep(150);
        Lift.rotateFor(0.7, rotationUnits::rev, 97, vex::velocityUnits::pct, false);   
        task::sleep(150); 
        driveTurnRightDegrees(35, 91);
        task::sleep(150);
        driveDistance (30, 21.5);
        lowpost();
        task::sleep(150);
        driveTurnRightDegrees(30,90);
        lowpost1();
        driveDistance (45, 6);
        Lift.rotateFor(-3.15, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
        task::sleep(150);
        driveTurnRightDegrees(35, 214);
        task::sleep(150);
        drivebackwardDistance(80, 41); 


        }
        else if(allianceBlue){   //blue


        }      

    }

}  