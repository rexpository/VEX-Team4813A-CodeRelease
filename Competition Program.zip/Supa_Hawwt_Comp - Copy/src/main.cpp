#include "userc.h"

vex::competition    Competition;

//
// Main will set up the competition functions and callbacks.
//
int main() {

    //Run the pre-autonomous function. 
    pre_auton();

    //Set up callbacks for autonomous and driver control periods.
    Competition.autonomous( autonomous );
    Competition.drivercontrol( usercontrol );

    // register events for button selection
    Brain.Screen.pressed( userTouchCallbackPressed );
    Brain.Screen.released( userTouchCallbackReleased );

    // cool background
    Brain.Screen.setFillColor( vex::color(black) );
    Brain.Screen.setPenColor( vex::color(black) );
    Brain.Screen.drawRectangle( 0, 0, 480, 120 );
    Brain.Screen.setFillColor( vex::color(black) );
    Brain.Screen.setPenColor( vex::color(black) );
    Brain.Screen.drawRectangle( 0, 120, 480, 120 );

    // initial display
    displayButtonControls( 0, false );

    while(1) {
        // Allow other tasks to run
        if( !Competition.isEnabled() )
        Brain.Screen.setFont(fontType::mono40);
        Brain.Screen.setFillColor( vex::color(yellow) );

        Brain.Screen.setPenColor( vex::color(black));
        Brain.Screen.printAt( 0,  133, "    YeLLA BeLYD FRaWG    " );
        this_thread::sleep_for(10);
    }
}






