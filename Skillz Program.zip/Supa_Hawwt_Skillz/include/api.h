#include "robot-config.h"
//Catapult Shooting during Autonomous
void catapultauto(){
    Catapult.rotateFor(3.01, rotationUnits::rev, 98, vex::velocityUnits::pct, false);
}

//Lowpost auto in autonomous
void lowpost(){
    Lift.rotateFor(0.9, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
    task::sleep(700);       
}

void lowpost1(){
    Lift.rotateFor(1.35, rotationUnits::rev, 97, vex::velocityUnits::pct, false); 
    task::sleep(150);
}

//Highpost auto in autonomous
void highpostauto(){
    Lift.rotateFor(0.9, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
}

void highpostauto1(){
    LiftExtension.rotateFor(-3.6, rotationUnits::rev, 97, vex::velocityUnits::pct,false);   
}

void highpostauto2(){
    Lift.rotateFor(1.35, rotationUnits::rev, 97, vex::velocityUnits::pct);
}

//Second highpost auto in autonomous, need to turn more due to motor wearing out
void highpostautoside(){
    Lift.rotateFor(1.02, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
}

void highpostautoside1(){
    LiftExtension.rotateFor(-3.6, rotationUnits::rev, 97, vex::velocityUnits::pct,false);  
}

void highpostautoside2(){
    Lift.rotateFor(1.35, rotationUnits::rev, 97, vex::velocityUnits::pct);
}

//Highpost auto going up in user control
void highpostup(){
    Lift.rotateFor(0.9, rotationUnits::rev, 97, vex::velocityUnits::pct, false);  
    task::sleep(25);    
    LiftExtension.rotateFor(-3.6, rotationUnits::rev, 97, vex::velocityUnits::pct,false); 
    task::sleep(25);    
    Lift.rotateFor(1.1, rotationUnits::rev, 97, vex::velocityUnits::pct);    
}        
      
//Highpost auto going down in user control
void highpostdown(){
    Lift.rotateFor(-0.9, rotationUnits::rev, 70, vex::velocityUnits::pct, false);
    task::sleep(25);
    LiftExtension.rotateFor(3.43, rotationUnits::rev, 70, vex::velocityUnits::pct, false);
    task::sleep(25);   
    Lift.rotateFor(-1.3, rotationUnits::rev, 70, vex::velocityUnits::pct, false);
    task::sleep(25);
}

//Intaking for some time
void intake(float count){
    Intake.rotateFor(-1 * count,rotationUnits::rev, 97,vex::velocityUnits::pct,false);
}

//Outaking for some time
void outake(float count){
    Intake.rotateFor(count,rotationUnits::rev,97,vex::velocityUnits::pct);
}

//initializes velocity for all drive motors percent
void driveSetVelocity( double speed)
{
    Leftfront.setVelocity(speed, vex::velocityUnits::pct); 
    Rightfront.setVelocity(speed, vex::velocityUnits::pct);
    Leftback.setVelocity(speed, vex::velocityUnits::pct); 
    Rightback.setVelocity(speed, vex::velocityUnits::pct); 
}

//moves robot forward # of rotations 
void drivefwd(double speed, float count)
{
    driveSetVelocity(speed);    // set the drive velocity for all four motors
    Leftfront.rotateFor(count, rotationUnits::rev,false);
    Leftback.rotateFor(count, rotationUnits::rev,false);
    Rightback.rotateFor(count, rotationUnits::rev,false);
    Rightfront.rotateFor(count, rotationUnits::rev);       
    task::sleep(50);   
}

//moves robot backward # of rotations
void drivebackward(double speed, float count)
{
    driveSetVelocity(speed);    // set the drive velocity for all four motors
    Leftfront.rotateFor(-1 * count, rotationUnits::rev,false);
    Leftback.rotateFor(-1 * count, rotationUnits::rev,false);
    Rightback.rotateFor(-1 * count, rotationUnits::rev,false);
    Rightfront.rotateFor(-1 * count, rotationUnits::rev);       // block until complete
    task::sleep(50);   
}


//tested distance for 5 revolutions - travelled 66", so each revolution travels 12.2"
//so to convert inches to revolutions divide distance by 12.2
void driveDistance(double speed, float distance)
{
    drivefwd(speed, distance*0.082);
}

//drive backward for # of distance
void drivebackwardDistance(double speed, float distance)
{
    drivebackward(speed, distance*0.082);
}

//rotate robot about center with drives turning opposite directions
void driveTurnFor(float count)
{
    Leftfront.rotateFor(-1.0*count, rotationUnits::rev,false);
    Leftback.rotateFor(-1.0*count, rotationUnits::rev,false);
    Rightback.rotateFor(count, rotationUnits::rev,false);
    Rightfront.rotateFor(count, rotationUnits::rev);  // block until complete
    task::sleep(50);   
}

//rotate robot about center with drives turning opposite directions
void driveTurnDegrees(double speed, float degrees)
{
    float rotdegree = 0.82/90;
 
    driveSetVelocity(speed);    // turn more slowly to avoid overshoot

    driveTurnFor( degrees * rotdegree );
 
}

//Turn left Degrees
//counter clockwise - so negative degrees
void driveTurnLeftDegrees(double speed, float degrees)
{   
    driveTurnDegrees(speed, 1.0 * degrees);       
}

//Turn Right Degrees
void driveTurnRightDegrees(double speed, float degrees)  
{
    driveTurnDegrees(speed, -1.0 * degrees);
}

void pre_auton( void ) {
}