#include "api.h"
void autonomous( void ) {

        // STEP 1
        //bakcwards into cap 
        //Intake ball
        //forward return back
        //turn Right face flags
        intake(68);
        drivebackwardDistance(40, 39.0);
        task::sleep(150);
        driveDistance(40, 40.03);
        task::sleep(150); 
        driveTurnRightDegrees(30, 92.09);
        task::sleep(150); 
        
        // STEP 2
        // forward to middle
        // shoot two flags
        // lift up
        // forward bump low flag
        driveDistance(45, 8.86);
        task::sleep(150); 
        catapultauto();
        task::sleep(700); 
        Lift.rotateFor(0.7, rotationUnits::rev, 97, vex::velocityUnits::pct, false);   
        task::sleep(550); 
        driveDistance(45, 25.56);
        task::sleep(150);
        Lift.rotateFor(-0.7, rotationUnits::rev, 97, vex::velocityUnits::pct, false);  
        task::sleep(25);
        
        // STEP 3       
        // backward move away from low flag
        // turn right
        // forward move into cap 
        // lift move up a bit
        // right 90
        // forward move under post
        // left 90
        // backwards a bit
        // high post
        // forward a bit
        intake(68);
        task::sleep(25);
        drivebackwardDistance(45, 11.95);
        task::sleep(150);
        driveTurnRightDegrees(30, 88.2);
        task::sleep(150);
        driveDistance(30, 9.42);
        task::sleep(150);
        Lift.rotateFor(0.6, rotationUnits::rev, 97, vex::velocityUnits::pct, false);  
        task::sleep(500);
        driveTurnRightDegrees(20, 90);
        task::sleep(150);
        driveDistance(30, 31.24);
        task::sleep(150);
        highpostauto();
        driveTurnLeftDegrees(30, 91.5);
        task::sleep(150);
        highpostauto1();
        drivebackwardDistance(30, 7.20);
        task::sleep(25);
        highpostauto2();
        intake(68);       
        driveDistance(45, 8.90);
        task::sleep(25);

        // STEP 4
        // high post down
        // turn left face flags
        // forward to flags
        // shoot two flags
        // lift up
        // hit low flag
        // lift down
        Lift.rotateFor(-2.95, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
        LiftExtension.rotateFor(3.6, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
        intake(68);
        driveTurnLeftDegrees(30, 56.75); 
        task::sleep(25);
        driveDistance(45, 28.7);
        task::sleep(500);
        catapultauto();
        task::sleep(700);
        Lift.rotateFor(0.8, rotationUnits::rev, 97, vex::velocityUnits::pct, false);   
        task::sleep(500); 
        driveDistance(45, 21.00);
        task::sleep(150);
        Lift.rotateFor(-0.8, rotationUnits::rev, 97, vex::velocityUnits::pct, false);  
        task::sleep(150);
        
        // STEP 5
        // backwards away from low flag
        // Turn Right
        // forward to cap
        // lift up 
        // forward a bit
        // turn right 90
        // forward to post
        // turn right
        // backwards a bit
        // high post
        // forward a bit
        // lift down
        drivebackwardDistance(45, 13.68);
        task::sleep(250);
        driveTurnRightDegrees(30, 56.75);
        task::sleep(150);
        driveDistance(35, 49.66);
        task::sleep(300);
        Lift.rotateFor(0.6, rotationUnits::rev, 97, vex::velocityUnits::pct, false);  
        task::sleep(500);
        driveDistance(30, 15.63);
        task::sleep(150);
        driveTurnRightDegrees(20, 90);
        task::sleep(150);
        driveDistance(30, 34.79);
        task::sleep(150);
        highpostautoside();       
        driveTurnRightDegrees(20, 90); 
        task::sleep(150);
        highpostautoside1();
        intake(68);
        drivebackwardDistance(30, 6.2);             
        task::sleep(150);
        highpostautoside2();
        driveDistance(30, 6.76);
        task::sleep(25);
        Lift.rotateFor(-2.95, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
        LiftExtension.rotateFor(3.6, rotationUnits::rev, 97, vex::velocityUnits::pct, false); 
        task::sleep(25);
    
        //STEP 6
        // turn right
        // forward to flags
        // turn left
        // forward to flags
        // turn right
        // shoot two flags
        // lift up
        // forward bump low flag
        // lift down
        driveTurnRightDegrees(30, 90.8);
        task::sleep(150);
        driveDistance(45, 24.38);
        task::sleep(250);
        catapultauto();
        task::sleep(700); 
        Lift.rotateFor(0.8, rotationUnits::rev, 97, vex::velocityUnits::pct, false);   
        task::sleep(750); 
        driveDistance(45, 21.95);
        Lift.rotateFor(-0.8, rotationUnits::rev, 97, vex::velocityUnits::pct, false);  
        task::sleep(150);               
    
        //STEP 7
        // backwards a bit
        // turn right
        // backwards a bit
        // turn left
        // backward up blue platform
        // turn right
        // backward up center platform
        drivebackwardDistance(45, 28.7);
        task::sleep(150);
        driveTurnRightDegrees(40, 88);
        task::sleep(150);
        intake(68);
        drivebackwardDistance(45, 28.98);
        task::sleep(150);
        driveDistance(40, 6.0);
        task::sleep(150);
        driveTurnLeftDegrees(40, 90);
        task::sleep(200);
        drivebackwardDistance(80, 34.5);
        task::sleep(200);
        driveTurnRightDegrees(40, 90);
        task::sleep(150);
        intake(68);
        drivebackwardDistance(100, 33.06);

}