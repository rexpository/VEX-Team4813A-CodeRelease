#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "v5.h"
#include "v5_vcs.h"
//
using namespace vex;
vex::brain Brain;
vex::motor Rightfront (vex::PORT1, vex::gearSetting::ratio18_1,true);
vex::motor Rightback (vex::PORT2, vex::gearSetting::ratio18_1,true);
vex::motor Leftfront (vex::PORT3, vex::gearSetting::ratio18_1,false);
vex::motor Leftback (vex::PORT4, vex::gearSetting::ratio18_1,false);
vex::motor LiftExtension (vex::PORT5, vex::gearSetting::ratio18_1,false);
vex::motor Lift (vex::PORT6, vex::gearSetting::ratio36_1,false);
vex::motor Intake (vex::PORT7, vex::gearSetting::ratio6_1,false);
vex::motor Catapult (vex::PORT20, vex::gearSetting::ratio36_1,true);
vex::gyro Gyro1( Brain.ThreeWirePort.E);
vex::pot CatPot( Brain.ThreeWirePort.C);
vex::pot LiftPot( Brain.ThreeWirePort.B);
vex::bumper Bump( Brain.ThreeWirePort.H);
vex::limit Limit( Brain.ThreeWirePort.F);
vex::controller Controller1;
vex::controller Controller2( vex::controllerType::partner );