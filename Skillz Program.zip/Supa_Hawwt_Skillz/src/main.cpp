#include "auton.h"

vex::competition    Competition;

void usercontrol( void ) {
    // In driver control, it will be advantageous to reverse the drive train direction so that the driver can
    // use the back cap flipper.
    bool lowspeed = false;
    bool drivereverse = false;
    bool motorLock = false;
    bool liftauto = true;
    bool autointake = true;

    while(true) {

        //Low Speed
        if(Controller2.ButtonUp.pressing()) {   
            lowspeed= true;
        } 
        
        if(Controller2.ButtonDown.pressing()) {              
            lowspeed = false;
        }  
        
        //Drive Reverse
        if(Controller2.ButtonX.pressing()) {
            drivereverse = true;
        }
        
        if(Controller2.ButtonB.pressing()) {
            drivereverse = false;
        }
        
        //LiftAuto
        if(Controller2.ButtonLeft.pressing()){
            liftauto = true;
        }
        
        if(Controller2.ButtonRight.pressing()){
            liftauto = false;
        }
        
        if(Controller1.ButtonB.pressing()){
            motorLock = false;
        }
        if(Controller1.ButtonX.pressing()){
            motorLock = true;
        }
        
        //MotorLock + Drive Reverse
        if(!motorLock){
            Leftfront.stop(vex::brakeType::brake);
            Leftback.stop(vex::brakeType::brake);
            Rightfront.stop(vex::brakeType::brake);
            Rightback.stop(vex::brakeType::brake);
        } 
        else{ 
            if(!drivereverse){
            if(!lowspeed) {
            Leftfront.spin(vex::directionType::fwd, Controller1.Axis3.value()/1.34, vex::velocityUnits::pct); //(Axis3+Axis4)/2 62.5%
            Leftback.spin(vex::directionType::fwd, Controller1.Axis3.value()/1.34, vex::velocityUnits::pct); //(Axis3+Axis4)/2
            Rightfront.spin(vex::directionType::fwd, Controller1.Axis2.value()/1.34, vex::velocityUnits::pct);//(Axis3-Axis4)/2
            Rightback.spin(vex::directionType::fwd, Controller1.Axis2.value()/1.34, vex::velocityUnits::pct);//(Axis3-Axis4)/2                
        } 
        else {
            Leftfront.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct); //(Axis3+Axis4)/2
            Leftback.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct); //(Axis3+Axis4)/2
            Rightfront.spin(vex::directionType::fwd, Controller1.Axis2.value(), vex::velocityUnits::pct);//(Axis3-Axis4)/2
            Rightback.spin(vex::directionType::fwd, Controller1.Axis2.value(), vex::velocityUnits::pct);//(Axis3-Axis4)/2        
        }              
            }
            else {
            if(!lowspeed) {
            Leftfront.spin(vex::directionType::rev, Controller1.Axis3.value()/1.34, vex::velocityUnits::pct); //(Axis3+Axis4)/2 62.5%
            Leftback.spin(vex::directionType::rev, Controller1.Axis3.value()/1.34, vex::velocityUnits::pct); //(Axis3+Axis4)/2
            Rightfront.spin(vex::directionType::rev, Controller1.Axis2.value()/1.34, vex::velocityUnits::pct);//(Axis3-Axis4)/2
            Rightback.spin(vex::directionType::rev, Controller1.Axis2.value()/1.34, vex::velocityUnits::pct);//(Axis3-Axis4)/2                
        } 
        else {

            Leftfront.spin(vex::directionType::rev, Controller1.Axis3.value(), vex::velocityUnits::pct); //(Axis3+Axis4)/2
            Leftback.spin(vex::directionType::rev, Controller1.Axis3.value(), vex::velocityUnits::pct); //(Axis3+Axis4)/2
            Rightfront.spin(vex::directionType::rev, Controller1.Axis2.value(), vex::velocityUnits::pct);//(Axis3-Axis4)/2
            Rightback.spin(vex::directionType::rev, Controller1.Axis2.value(), vex::velocityUnits::pct);//(Axis3-Axis4)/2        
        } 
            }
        //Right 90
        if(Controller1.ButtonRight.pressing()) { 
            driveTurnRightDegrees(40, 89.0);
        }            
        //Left 90
        if(Controller1.ButtonLeft.pressing()){
            driveTurnLeftDegrees(40, 89.0);
        } 
        //Left 45
        if(Controller1.ButtonY.pressing())  {
            driveTurnLeftDegrees(40, 44.0);
        }   
        //Right 45
        if(Controller1.ButtonA.pressing()){
            driveTurnRightDegrees(40, 44.0);
        }    
        //Right 180
        if(Controller2.ButtonA.pressing()){
            driveTurnRightDegrees(40, 180.0);
        }
        //Left 180
        if(Controller2.ButtonY.pressing()){
            driveTurnLeftDegrees(40, 180.0);
        }
        }    
        
        //Intake
        if(Controller1.ButtonL2.pressing()) { 
            autointake = false;           
        } 
        if(Controller1.ButtonL1.pressing()){ 
            autointake = true;          
        } 
        if(!autointake){
                Intake.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);           
        } 
        else if(Controller1.ButtonL1.pressing()){
                Intake.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct); 
        }
        else{
            Intake.stop(brakeType::coast);
        }
        
        //Catapult
        if(Controller1.ButtonR1.pressing()) { 

//Catapult Reload in UserControl
//3 revolutions for red gear catridge
    Catapult.rotateFor(0.7, rotationUnits::rev, 99, vex::velocityUnits::pct);
    while(true){      
        if (CatPot.value(analogUnits::range12bit) < 460) {
            
         Catapult.spin(fwd, 99, vex::velocityUnits::pct);
            
         Leftfront.spin(vex::directionType::fwd, Controller1.Axis3.value()/1.34, vex::velocityUnits::pct); //(Axis3+Axis4)/2 62.5%
         Leftback.spin(vex::directionType::fwd, Controller1.Axis3.value()/1.34, vex::velocityUnits::pct); //(Axis3+Axis4)/2
         Rightfront.spin(vex::directionType::fwd, Controller1.Axis2.value()/1.34, vex::velocityUnits::pct);//(Axis3-Axis4)/2
         Rightback.spin(vex::directionType::fwd, Controller1.Axis2.value()/1.34, vex::velocityUnits::pct);//(Axis3-Axis4)/2  
        //Intake
        if(Controller1.ButtonL2.pressing()) { 
            autointake = false;           
        } 
        if(Controller1.ButtonL1.pressing()){ 
            autointake = true;          
        } 
        if(!autointake){
                Intake.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);           
        } 
        else if(Controller1.ButtonL1.pressing()){
                Intake.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct); 
        }
        else{
            Intake.stop(brakeType::coast);
        }               
        if(!liftauto){

        //High Post
        if(Controller2.ButtonL1.pressing()) {
            highpostup();
        }
        else if(Controller2.ButtonL2.pressing()) {
            highpostdown();
        }           
        //Low Post
        else if(Controller2.ButtonR1.pressing()) {
            lowpost();
        }
        else if(Controller2.ButtonR2.pressing()) {
            Lift.rotateFor(-2.9, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
            task::sleep(25);            
        }  
        }
        else{
        //Lift
        if(Controller2.ButtonL1.pressing()) {
            Lift.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
        }
        else if(Controller2.ButtonL2.pressing()) { 
            Lift.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
        }    
        else{
            Lift.stop(vex::brakeType::hold);
        }
        
        //LiftExtender
        if(Controller2.ButtonR1.pressing()) { 
            LiftExtension.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
        } 
        else if(Controller2.ButtonR2.pressing()) { 
            LiftExtension.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
        } 
        else{
            LiftExtension.stop(vex::brakeType::hold);
        }                        
        }
        }
        else {
         Catapult.stop(brake);
        //MotorLock + Drive Reverse
            Leftfront.spin(vex::directionType::fwd, Controller1.Axis3.value()/1.34, vex::velocityUnits::pct); //(Axis3+Axis4)/2 62.5%
            Leftback.spin(vex::directionType::fwd, Controller1.Axis3.value()/1.34, vex::velocityUnits::pct); //(Axis3+Axis4)/2
            Rightfront.spin(vex::directionType::fwd, Controller1.Axis2.value()/1.34, vex::velocityUnits::pct);//(Axis3-Axis4)/2
            Rightback.spin(vex::directionType::fwd, Controller1.Axis2.value()/1.34, vex::velocityUnits::pct);//(Axis3-Axis4)/2                    
        
        //Intake
        if(Controller1.ButtonL2.pressing()) { 
            autointake = false;           
        } 
        if(Controller1.ButtonL1.pressing()){ 
            autointake = true;          
        } 
        if(!autointake){
                Intake.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);           
        } 
        else if(Controller1.ButtonL1.pressing()){
                Intake.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct); 
        }
        else{
            Intake.stop(brakeType::coast);
        }
            
        if(!liftauto){

        //High Post
        if(Controller2.ButtonL1.pressing()) {
            highpostup();
        }
        else if(Controller2.ButtonL2.pressing()) {
            highpostdown();
        }           
        //Low Post
        else if(Controller2.ButtonR1.pressing()) {
            lowpost();
        }
        else if(Controller2.ButtonR2.pressing()) {
            Lift.rotateFor(-2.9, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
            task::sleep(25);            
        }  
        }
        else{
        //Lift
        if(Controller2.ButtonL1.pressing()) {
            Lift.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
        }
        else if(Controller2.ButtonL2.pressing()) { 
            Lift.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
        }    
        else{
            Lift.stop(vex::brakeType::hold);
        }
        
        //LiftExtender
        if(Controller2.ButtonR1.pressing()) { 
            LiftExtension.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
        } 
        else if(Controller2.ButtonR2.pressing()) { 
            LiftExtension.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
        } 
        else{
            LiftExtension.stop(vex::brakeType::hold);
        }            
         break;
        }
    }
}
        }
        else if(Controller1.ButtonR2.pressing()) {
            Catapult.rotateFor(0.3,timeUnits::sec, 100, vex::velocityUnits::pct);  
            task::sleep(25);
        }

               
        if(!liftauto){

        //High Post
        if(Controller2.ButtonL1.pressing()) {
            highpostup();
        }
        else if(Controller2.ButtonL2.pressing()) {
            highpostdown();
        }           
        //Low Post
        else if(Controller2.ButtonR1.pressing()) {
            lowpost();
        }
        else if(Controller2.ButtonR2.pressing()) {
            Lift.rotateFor(-2.9, rotationUnits::rev, 97, vex::velocityUnits::pct, false);
            task::sleep(25);            
        }  

        }
        else{
        //Lift
        if(Controller2.ButtonL1.pressing()) {
            Lift.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
        }
        else if(Controller2.ButtonL2.pressing()) { 
            Lift.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
        }    
        else{
            Lift.stop(vex::brakeType::hold);
        }
        
        //LiftExtender
        if(Controller2.ButtonR1.pressing()) { 
            LiftExtension.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
        } 
        else if(Controller2.ButtonR2.pressing()) { 
            LiftExtension.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
        } 
        else{
            LiftExtension.stop(vex::brakeType::hold);
        }
        } 
       
        vex::task::sleep(20); 
    }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {

    //Run the pre-autonomous function. 
    pre_auton();
    Brain.Screen.print(CatPot.value(analogUnits::range12bit));
    //Set up callbacks for autonomous and driver control periods.
    Competition.autonomous( autonomous );
    Competition.drivercontrol( usercontrol );

}







